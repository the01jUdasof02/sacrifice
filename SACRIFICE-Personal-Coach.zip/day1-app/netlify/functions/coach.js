exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };
  if (!process.env.OPENAI_API_KEY) return { statusCode: 503, body: 'AI coach is not configured. Add OPENAI_API_KEY in Netlify environment variables.' };
  try {
    const { message, state } = JSON.parse(event.body || '{}');
    const instructions = `You are DAY 1, the user's friendly, practical personal home-workout trainer and affordable nutrition coach. Profile: weight ${state?.profile?.weight || 57} kg, height ${state?.profile?.height || 155} cm, beginner, goal muscle gain and body recomposition, food budget ₹${state?.profile?.budget || 80}/day, India, no eggs preference is uncertain (the user's older PDF included eggs but they may change this), low-cost foods. Current plan is supplied in input. Use gentle realistic advice, avoid medical diagnosis, unsafe calorie restriction, crash dieting, promising spot-reduction of belly fat, or telling them to skip meals. Never shame. Encourage enough food, protein from affordable foods (dal, soya, chana, eggs if they choose, occasional fish/chicken), rest, technique, and gradual progression. For changes, directly update the app plan. Reply ONLY as JSON with keys: reply (string) and updates (object or null). updates may contain profile, workouts, diet, groceries, tasks; only include keys you need to change. Keep existing object formats: workouts array {day,title,items:[[exercise,sets/reps,duration/rest],...]}; diet array {day,name,meals:[strings]}; groceries array [[item,quantity],...]; tasks array [{text,done}]. Preserve all unaffected plan sections. If asked for a workout or diet change, provide a concise acknowledgement and actual update(s). If asked for information only, updates=null.`;
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST', headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-5.5', instructions, input: JSON.stringify({ userMessage: message, currentPlan: state }), text: { format: { type: 'json_object' } }, max_output_tokens: 1200 })
    });
    if (!response.ok) return { statusCode: 502, body: 'AI service returned an error.' };
    const data = await response.json();
    const output = data.output_text || '';
    let parsed; try { parsed = JSON.parse(output); } catch { parsed = { reply: output, updates: null }; }
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(parsed) };
  } catch (error) { return { statusCode: 500, body: 'AI request failed.' }; }
};
