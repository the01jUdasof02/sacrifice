# SACRIFICE — Personal Fitness Coach

Phone-first progressive web app with offline-friendly local tracking, beginner home workouts, affordable Indian meal plan, grocery checklist, progress notes, and an AI trainer function.

## Deploy to Netlify (free hosting; AI API usage may cost money)
1. Create a GitHub repository and upload these project files, or use Netlify's manual deploy for the static app (AI function requires a full project deploy).
2. In Netlify, import the repository and deploy. Build command can be blank; publish directory is `.`.
3. Site settings → Environment variables: add `OPENAI_API_KEY` with your OpenAI API key. Optional `OPENAI_MODEL` (default `gpt-5.5`). Never put the key in frontend files.
4. Redeploy after adding the key. Open the site on your phone, browser menu → **Add to Home screen** or **Install app**.

## Notes
- App data is stored in the browser's local storage on the device; clearing browser storage can erase it. This version does not sync across devices.
- The AI endpoint is a Netlify Function; it only works after deployment with the API key configured.
- Meal budget estimates are targets, not live local prices. Adjust in AI Coach by asking to change the daily budget.
- The plan is general fitness guidance, not individualized medical care. Keep meals adequate; avoid crash dieting.
